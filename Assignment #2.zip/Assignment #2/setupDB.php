<?php
try {
$pdo = new PDO('sqlite:database.sqlite');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL
)");
 $count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
 if ($count == 0) {
     for ($i = 1; $i <= 100; $i++) {
         $pdo->exec("INSERT INTO users (name, email) VALUES ('User$i', 'user$i@example.com')");
     }
 }
 echo "The database was created and data was added successfully.";
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>