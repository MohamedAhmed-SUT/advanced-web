<?php

$dbFile = 'database.sqlite';
$dsn = "sqlite:$dbFile";

try {
    $pdo = new PDO($dsn);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $rowsPerPage = 20;
    $offset = ($page - 1) * $rowsPerPage;

    $stmt = $pdo->prepare("SELECT * FROM users LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $rowsPerPage, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $users_assoc = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $stmt->execute();
    $users_num = $stmt->fetchAll(PDO::FETCH_NUM);
    
    $stmt->execute();
    $users_obj = [];
    while ($user = $stmt->fetchObject()) {
        $users_obj[] = $user;
    }
    
    $stmt = $pdo->query("SELECT email FROM users LIMIT 1");
    $email = $stmt->fetchColumn();
    
    $totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $totalPages = ceil($totalUsers / $rowsPerPage);

} catch (PDOException $e) {
    die("Database connection error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User List with Fetch Methods</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>User List</h2>
    <ul class="user-list">
    <?php foreach ($users_assoc as $user): ?>
        <li><?php echo $user['name']; ?> - <?php echo $user['email']; ?></li>
    <?php endforeach; ?>
    </ul>

    <h3>FETCH_ASSOC</h3>
    <pre><code><?php print_r($users_assoc); ?></code></pre>

    <h3>FETCH_NUM</h3>
    <pre><code><?php print_r($users_num); ?></code></pre>

    <h3>FETCH_OBJECT</h3>
    <pre><code><?php print_r($users_obj); ?></code></pre>

    <h3>FETCH_COLUMN (First Email)</h3>
    <p><?php echo $email; ?></p>

    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>">Previous</a>
        <?php endif; ?>

        <?php if ($page < $totalPages): ?>
            <a href="?page=<?php echo $page + 1; ?>">Next</a>
        <?php endif; ?>
    </div>
</body>
</html>